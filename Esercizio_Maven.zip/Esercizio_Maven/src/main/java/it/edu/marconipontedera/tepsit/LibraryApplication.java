package it.edu.marconipontedera.tepsit;

@ApplicationPath("api")
public class LibraryApplication extends ResourceConfig {
    public LibraryApplication() {
        packages("it.edu.marconipontedera.tepsit");
    }
}