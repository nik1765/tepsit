
public class Sincronizzatore {
	int conta=0;
	public synchronized void incrementa(){
		conta++;
	}
	public synchronized int get() {
		return conta;
	}

}
