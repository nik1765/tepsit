import java.util.Scanner;
import java.util.Random;
public class Main {

	public static void main(String[] args) {
		int t, n, x;
		int time=120;
		int ms=500;
		boolean stato;
		Sincronizzatore conta=new Sincronizzatore();
		
		Random random=new Random();
		
		Scanner cin = new Scanner(System.in);
		System.out.println("Quanti thread vuoi creare?\n -> ");
		t = cin.nextInt();
		
		System.out.println("Qual'è il valore massimo a cui si può contare?\n -> ");
		n = cin.nextInt();
	Thread[] contatori = new Thread[t];
		
		for (int i = 0; i < contatori.length; i++) {
			x=random.nextInt(n);
			Contatore c=new Contatore(x,time,conta);
			contatori[i]=new Thread(new Contatore(x, time, conta));
		}
		
		for (int i = 0; i < contatori.length; i++) {
			contatori[i].start();
		}
		do {
			stato=false;
			try {
				Thread.sleep(ms);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			for(int i=0; i<contatori.length; i++) {
				if(contatori[i].isAlive()==true) {
					System.out.println(conta.get());
					stato=true;
				}else {
					System.out.println("COMPLETATO\n");
					
				}
			}
		}while(stato==true);
		System.out.println("TUTTI THREAD COMPLETATI");
	}

}
