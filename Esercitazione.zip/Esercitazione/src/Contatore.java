
public class Contatore implements Runnable{
	private int x, time;
	private Sincronizzatore conta;
	public Contatore(int x, int time, Sincronizzatore conta) {
		this.x=x;
		this.time=time;
		this.conta=conta;
	}
	@Override
	public void run() {
		for(int i=0; conta.get() < x; i++ ) {
			try {
				Thread.sleep(time);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			conta.incrementa();
			
		}
	}
}
